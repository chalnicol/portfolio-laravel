

<div id="contacts" class="bg-gray-900 py-8">
    <div class="max-w-7xl mx-auto lg:flex px-5 gap-12" >

        <div class="w-full lg:w-1/2 text-white mb-12 lg:mb-0">
            <h1 class="text-2xl font-bold mb-2">Contacts</h1>
            <hr class="border-white border-b">

            <div class="flex items-center gap-4 my-3 text-gray-300">
                <span class="material-symbols-outlined">
                    mail
                </span>
                <span><?php echo e($data['profile']['details']['email']); ?></span>
            </div>

            <div class="flex items-center gap-4 my-3 text-gray-300">
                <span class="material-symbols-outlined">
                    globe
                </span>
                <span><?php echo e($data['profile']['details']['website']); ?></span>

            </div>
            <div class="flex items-center gap-4 my-3 text-gray-300">
                <span class="material-symbols-outlined">
                    smartphone
                </span>
                <span><?php echo e($data['profile']['details']['phone']); ?></span>

            </div>
            <div class="flex items-center gap-4 my-3 text-gray-300">
                <span class="material-symbols-outlined">
                    home
                </span>
                <span><?php echo e($data['profile']['details']['address']); ?></span>

            </div>

            <h1 class="text-2xl font-bold mb-2 mt-12">Socials</h1>
            <hr class="border-white border-b">
            <div class="flex gap-4 mt-4 px-0">

                <?php $__currentLoopData = $data['profile']['details']['socials']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="h-8 w-8 overflow-hidden shadow-lg z-auto">
                    <a href="<?php echo e($social['url']); ?>" target="_blank">
                        <img class="w-full h-full" src="<?php echo e(asset('assets/images/socials/'. $social['thumbnail'] )); ?>" alt="<?php echo e($social['name']); ?>">
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>

        <div class="w-full lg:w-1/2 text-white">
            <h1 class="text-2xl font-bold mb-2">Leave A Message</h1>
            <hr class="border-white border-b">

            <form action="<?php echo e(route('send.message')); ?>" method="POST">

               <?php echo csrf_field(); ?>
                <div class="my-2">
                    
                    <input type="text" name="name" id="name" class="w-full h-10 rounded my-1 px-3 text-black" placeholder="Enter your name" required>
                </div>
                <div class="my-2">
                    
                    <input type="text" name="email" id="email" class="w-full h-10 rounded my-1 px-3 text-black" placeholder="Enter your e-mail" required>
                </div>
                <div class="my-2">
                    
                    <textarea name="message" id="message" class="w-full h-32 rounded my-1 p-3 text-black" placeholder="Enter message here" required></textarea>
                </div>
                <button type="submit" class="w-full bg-gray-500 py-3 rounded-md text-xl font-bold hover:bg-gray-400">SUBMIT</button>
            </form>

            <br><br>
        </div>

    </div>
</div><?php /**PATH C:\Users\chaln\Documents\projects\portfolio-laravel-app\resources\views\components\footer.blade.php ENDPATH**/ ?>