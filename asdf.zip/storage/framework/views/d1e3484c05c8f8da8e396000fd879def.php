


<div style="height:100%;width:100%;font-family:Arial, Helvetica, sans-serif">
    <div style="background-color:#cecece;padding:12px;font-size:16px;">
        <strong>Message from <?php echo e(ucfirst($details['name'])); ?> &lt; <?php echo e($details['email']); ?> &gt;</strong>
    </div>

    <div style="background-color:#9c9c9c;padding:12px;font-size:14px;">
        <?php echo nl2br(e($details['message'])); ?>

    </div>
</div>
    <?php /**PATH C:\Users\chaln\Documents\projects\portfolio-laravel-app\resources\views\mail\message-from-site.blade.php ENDPATH**/ ?>